### 8300  ACCOUNT NUKER  VERISON:
its just simple accoutn nuker or can use it full closing dm and leaving server

### Current Worked Benchmarks:
- Working: `1000%`
- NotWorking: `26%`


| SS OF THE TOOL| 
| ------------- | 
| ![image](https://cdn.discordapp.com/attachments/835677126958776320/845065629035397130/unknown.png) |
